<?php
header('Content-Type: application/json');

// Connect to database
require_once 'db.php';

// Read JSON request body
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['phoneNumber']) && isset($data['password']) && isset($data['pin'])) {
    $phone    = filter_var($data['phoneNumber'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $password = filter_var($data['password'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $pin      = filter_var($data['pin'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    // SQL query using backticks around column name with space: `phone number`
    $stmt = $conn->prepare("INSERT INTO `users` (`phone number`, `password`, `pin`) VALUES (?, ?, ?)");
    
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Prepare statement failed: " . $conn->error]);
        exit();
    }

    $stmt->bind_param("sss", $phone, $password, $pin);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Data saved to database successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Execution failed: " . $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Required form fields are missing."]);
}

$conn->close();
?>