<?php
header('Content-Type: application/json');

// 1. Include the database connection
require_once 'db.php';

// 2. Get the submitted JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['phoneNumber']) && isset($data['password']) && isset($data['pin'])) {
    $phone = $data['phoneNumber'];
    $password = $data['password'];
    $pin = $data['pin'];

    // 3. Save into your `users` table
    $stmt = $conn->prepare("INSERT INTO users (phone_number, password, pin) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $phone, $password, $pin);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Data saved successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to save data."]);
    }

    $stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Missing form data."]);
}

$conn->close();
?>