<?php
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "tirva_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database Connection Failed: " . $conn->connect_error]));
}

$conn->set_charset("utf8mb4");
?>